<?php
date_default_timezone_set('America/Guayaquil');

$host = "localhost";
$db = "abrilcrm03";
$username = "_abrilcrm03";
$password = "CONTRASEÑA";

error_reporting(0);

// Conexión a la base de datos
$conn = mysqli_connect($host, $username, $password, $db) or die("¡Error al conectar con la base de datos!");

// Verificar conexión
if (!$conn) {
    die("Conexión fallida: " . mysqli_connect_error());
}

$app_name = "CRM";
$c_name = "CRM";
$url_demo = "https://PONER DNS/demo.php";


?>
