<footer class="footer text-center text-muted">
    Todos los derechos reservados por CRM. Diseñado y desarrollado por <a
        href="https://t.me/CRMwhatsapp" target="_blank">CRM LLC</a>.
</footer>