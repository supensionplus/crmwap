<aside class="left-sidebar" data-sidebarbg="skin6">
  <div class="scroll-sidebar" data-sidebarbg="skin6">
    <nav class="sidebar-nav pt-2">
      <ul id="sidebarnav">
        <li class="sidebar-item"> <a class="sidebar-link sidebar-link" id="sid-main" href="index.php"
            aria-expanded="false"><i data-feather="home" class="feather-icon"></i><span
              class="hide-menu">Tablero</span></a></li>
        <li class="list-divider"></li>
        <?php
        if ($_SESSION['user_type'] == 'admin') {
        ?>
          <li class="nav-small-cap"><span class="hide-menu">Licencias</span></li>

          <li class="sidebar-item"> <a class="sidebar-link" href="all-licenses.php" id="sid-add"
              aria-expanded="false"><i class="fas fa-address-card"></i><span
                class="hide-menu">Todas las licencias
              </span></a>
          </li>
          <li class="sidebar-item"> <a class="sidebar-link" href="add-license.php" id="sid-add"
              aria-expanded="false"><i class="fas fa-plus-circle"></i><span
                class="hide-menu">Nueva licencia
              </span></a>
          </li>

          <li class="list-divider"></li>
          <li class="nav-small-cap"><span class="hide-menu">Vendedores</span></li>
          <li class="sidebar-item"> <a class="sidebar-link" href="all-reseller.php" id="sid-add"
              aria-expanded="false"><i class="fas fa-user"></i><span
                class="hide-menu">Vendedores
              </span></a>
          </li>
          <li class="sidebar-item"> <a class="sidebar-link" href="add-reseller.php" id="sid-add"
              aria-expanded="false"><i class="fas fa-user-plus"></i><span
                class="hide-menu">Nuevo Vendedor
              </span></a>
          </li>

          <li class="list-divider"></li>
          <li class="nav-small-cap"><span class="hide-menu">Administradores</span></li>
          <li class="sidebar-item"> <a class="sidebar-link" href="all-admins.php" id="sid-add"
              aria-expanded="false"><i class="fas fa-unlock-alt"></i><span
                class="hide-menu">Administradores
              </span></a>
          </li>
          <li class="sidebar-item"> <a class="sidebar-link" href="add-admin.php" id="sid-add"
              aria-expanded="false"><i class="fas fa-plus-circle"></i><span
                class="hide-menu">Nuevo Admin
              </span></a>
          </li>

          <li class="list-divider"></li>
          <li class="sidebar-item"> <a class="sidebar-link sidebar-link" target="_blank" href="https://drive.usercontent.google.com/u/0/uc?id=1NSFwKb6z73yASbM4z0bw-gotnon7Dz5q&export=download"
              aria-expanded="false"><i class="far fa-arrow-alt-circle-down"></i><span
                class="hide-menu">Descargar Extension</span></a></li>
        <?php } else { ?>
          <li class="nav-small-cap"><span class="hide-menu">Licencias</span></li>

          <li class="sidebar-item"> <a class="sidebar-link" href="all-licenses.php" id="sid-add"
              aria-expanded="false"><i class="fas fa-address-card"></i><span
                class="hide-menu">Todas las licencias
              </span></a>
          </li>
          <li class="sidebar-item"> <a class="sidebar-link" href="add-license.php" id="sid-add"
              aria-expanded="false"><i class="fas fa-plus-circle"></i><span
                class="hide-menu">Nueva licencia
              </span></a>
          </li>
        <?php } ?>
      </ul>
    </nav>
  </div>
</aside>