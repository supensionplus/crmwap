<?php
$DBCON['host'] = 'localhost';
$DBCON['user'] = '';
$DBCON['pass'] = '';
$DBCON['name'] = '';
?>