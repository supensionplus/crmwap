$(document).ready(function () {
    'use strict';

    //********* page loader js

    setTimeout(function () {
        $('.loader_bg').fadeToggle();
    }, 1500);


    //********** menu background color change while scroll

    if ($(window).scrollTop()===0){
        $('#nav-area').removeClass('scroll-nav');
    }
    else{
        $('#nav-area').addClass('scroll-nav');
    }

    $(window).scroll(function(){
        if ($(window).scrollTop()===0){
            $('#nav-area').removeClass('scroll-nav');
        }
        else{
            $('#nav-area').addClass('scroll-nav');
        }
    });

    //********* Typed js

    var element = $(".text-affect");

    $(function(){
        element.typed({
            strings: ["Optimiza tu negocio", "Gestiona tus clientes fácilmente"],
            loop: true,
            typeSpeed: 90
        });
    });

    //************ Smooth Scroll js

    $('a.smooth-menu,a.custom-btn-1,a.custom-btn-2,a.custom-btn-3,a.demo-site-btn').on("click", function (e) {
        e.preventDefault();
        var anchor = $(this);
        $('html, body').stop().animate({
            scrollTop: $(anchor.attr('href')).offset().top - 50
        }, 1000);
    });


    // start all the timers
    $('.counter').counterUp({
        delay: 50,
        time: 8000
    });

    //*********** scrollspy js

    $('body').scrollspy({
        target: '.navbar-collapse',
        offset: 195
    });

    //*************** About Tab

    $(".btn-pref .btn").click(function () {
        $(".btn-pref .btn").removeClass("btn-primary").addClass("btn-default");
        $(this).removeClass("btn-default").addClass("btn-primary");
    });


    //********* Client testimonial

    $('.client-testimonial-carousel').owlCarousel({
        loop: true,
        margin: 10,
        nav: false,
        dots: true,
        autoplay: false,
        responsive:{
            0:{
                items:1
            },
            600:{
                items:2
            },
            1000:{
                items:3
            }
        }
    })    

    //************ Magnific Popup
   

    $('.zoom1').magnificPopup({
        type: 'image',
        gallery: {
            enabled: true
        }
    });




});