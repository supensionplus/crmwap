<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, X-Requested-With");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Content-Type: application/json");

include("../include/conn.php");
include("../include/function.php");

$response = [
  "message_code" => 200,
  "data" => [
    "key" => "",
    "promotion" => [
      "day" => "01",
      "slider" => [
        [
          "link" => "https://wa.me/56990697972",
          "image" => "https://crm03.driveto.online/api/assets/img/logo/logo.png"
        ]
      ],
      "title" => "WhatsApp CRM Premium",
      "code" => "By CRM"
    ],
    "expired" => [
      "image" => "https://crm03.driveto.online/api/assets/img/logo/logo.png",
      "title" => "Renueva tu licencia expirada hoy",
      "description" => "¿Tu licencia ha expirado? No te preocupes, renueva fácilmente y vuelve a disfrutar de todos los beneficios. Mantén tu acceso activo y evita interrupciones en tu servicio. ¡Haz clic ahora para renovar y continuar sin problemas!",
      "button" => [
        "link" => "https://wa.me/56990697972",
        "title" => "Renueva tu licencia expirada hoy"
      ]
    ],
    "default_image" => [
      "default_image_user" => "https://crm03.driveto.online/api/assets/img/logo/logo.png",
      "default_image_group" => "https://crm03.driveto.online/api/assets/img/logo/logo.png"
    ],
    "system_icons" => [
      "icon_search" => "https://crm03.driveto.online/api/assets/img/logo/logo.png"
    ],
    "global" => [
      "color_ligth_primary" => "#04d79e",
      "color_dark_primary" => "#04d79e"
    ],
    "logo" => [
      "data" => [
        "logo_image" => "https://crm03.driveto.online/api/assets/img/logo/logo.png",
        "logo_link" => [
          "title" => "CRM 5",
          "url" => "https://wa.me/56990697972",
          "target" => ""
        ]
      ],
      "style" => [
        "logo_background_ligth" => "#ffffff",
        "logo_background_dark" => "#222e35"
      ]
    ],
    "buttons" => [
      "data" => [
        [
          "id" =>  "sending_messages",
          "title" =>  "⚡📢 Transmisiones",
          "sub_title" =>  "Transmisiones rápidas y de emergencia",
          "icon" =>  "https://crm03.driveto.online/api/assets/img/menu/transmisiones.png",
          "help" =>  "<p>.</p>\n"
        ],
        [
          "id" =>  "lists",
          "title" =>  "🏷️🔖 Pestañas Personalizadas",
          "sub_title" =>  "Empareja tus etiquetas y organiza como un profesional",
          "icon" =>  "https://crm03.driveto.online/api/assets/img/menu/pestaдas.png",
          "help" =>  "<p>.</p>\n"
        ],
        [
          "id" =>  "templates",
          "title" =>  "📃 Plantillas",
          "sub_title" =>  "Crea y organiza tus plantillas",
          "icon" =>  "https://crm03.driveto.online/api/assets/img/menu/plantillas.png",
          "help" =>  "<p>.</p>\n"
        ],
        [
          "id" =>  "workflow",
          "title" =>  "🤖 Chatbots",
          "sub_title" =>  "Crea y personaliza tu chatbot de autorespuesta",
          "icon" =>  "https://crm03.driveto.online/api/assets/img/menu/chatbot.png",
          "help" =>  "<p>.</p>\n"
        ],
        [
          "id" =>  "schedule_messages",
          "title" =>  "📅 Difusiones Programadas",
          "sub_title" =>  "Programa todos tus mensajes",
          "icon" =>  "https://crm03.driveto.online/api/assets/img/menu/difuciones.png",
          "help" =>  "<p>.</p>\n"
        ],
        [
          "id" =>  "scheduled_shipments",
          "title" =>  "🗓️⏰ Notificaciones Programadas",
          "sub_title" =>  "Notifica a un cliente en el futuro",
          "icon" =>  "https://crm03.driveto.online/api/assets/img/menu/notificaciones.png",
          "help" =>  "<p>.</p>\n"
        ],
        [
          "id" =>  "notes",
          "title" =>  "🗒️ Respuestas rapidas",
          "sub_title" =>  "Agrege las respiestas rapidas!",
          "icon" =>  "https://crm03.driveto.online/api/assets/img/menu/notas.png",
          "help" =>  "<p>.</p>\n"
        ],
        [
          "id" =>  "reminder",
          "title" =>  "🔔  Tablero Kanba",
          "sub_title" =>  "Organiza todos tus clientes con esta poderosa herramienta",
          "icon" =>  "https://crm03.driveto.online/api/assets/img/menu/kanban.png",
          "help" =>  "<p>.</p>\n"
        ],
        [
          "id" =>  "kanban_board",
          "title" =>  "🗃️📋Funciones",
          "sub_title" =>  "Importa y exporta contactos, enlaces personalizados y mucho más...",
          "icon" =>  "https://crm03.driveto.online/api/assets/img/menu/funciones.png",
          "help" =>  "<p>.</p>\n"
        ],
        [
          "id" =>  "functions",
          "title" =>  "🕹️ Herramientas",
          "sub_title" =>  "Conjuntos de funciones gratuitas",
          "icon" =>  "https://crm03.driveto.online/api/assets/img/menu/herramientas.png",
          "help" =>  "<p>.</p>\n"
        ],
        [
          "id" =>  "tools_free",
          "title" =>  "Usuario",
          "sub_title" =>  "Tu panel de usuario privado",
          "icon" =>  "https://crm03.driveto.online/api/assets/img/menu/usuario.png",
          "help" =>  "<p>.</p>\n"
        ],
        [
          "id" =>  "user",
          "title" =>  "🗣️✨ Usuario",
          "sub_title" =>  "Tu panel de usuario privado",
          "icon" =>  "https://crm03.driveto.online/api/assets/img/botia/usuario.png",
          "help" =>  "<p>.</p>\n"
        ]
      ],
      "styles" => [
        "btn_background_ligth" => "#ffffff",
        "btn_icon_background_ligth" => "#ffffff",
        "btn_text_ligth" => "#04d79e",
        "btn_background_dark" => "#ffffff",
        "btn_icon_background_dark" => "#202c33",
        "btn_text_dark" => "#04d79e"
      ]
    ],
    "loading" => [
      "loading_image" => "https://pkfamily.xyz/assets/icons/cargando-2.gif",
      "loading_title" => "CRM 5 5.5",
     "loading_title_description" => "<div style=\"text-align: center;\">\n
    <strong>Bienvenido a WhatsApp CRM</strong>🙏<br />\n
      <strong>Cargando Bibliotecas&#8230;</strong>😁<br />\n
    <a href=\"https://wa.me/56990697972\" target=\"_blank\" style=\"text-decoration: none;\">\n
        <button style=\"margin-top: 15px; padding: 10px 20px; background-color: #4CAF50; color: white; border: none; border-radius: 5px; cursor: pointer;\">Comprar Licencia</button>\n
    </a>\n
</div>\n",
      "loading_button" => "<p>Close</p>\n"
    ],
    "table_price" => [
      [
        "id" => 1122,
        "url" => "https://wa.me/56990697972",
        "title" => "WhatsApp CRM Premium",
        "description" => "<strong>TODAS LAS FUNCIONALIDADES ACTIVAS</strong>",
        "features" => [
          "Automatización de mensajes ",
          "Mensajería ilimitada ",
          "Funcionalidad de etiquetado y segmentación de contactos ",
          "Gestión de contactos ilimitada ",
          "Historial completo de conversaciones ",
          "Informes y análisis detallados ",
          "Integración avanzada con WhatsApp ",
          "Soporte prioritario por correo electrónico y chat en vivo ",
          "Todas las características disponibles"
        ],
        "regular_price" => "<span class=\"woocommerce-Price-amount amount\"><bdi><span class=\"woocommerce-Price-currencySymbol\">CONTACTAR</span></bdi></span>",
        "old_price" => null,
        "currency_symbol" => "USD",
        "subscription_time" => "1 mes",
        "variations" => []
      ]
    ]
  ]
];

echo json_encode($response);
