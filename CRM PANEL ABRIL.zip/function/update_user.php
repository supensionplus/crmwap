<?php
include("../include/conn.php");
include("../include/function.php");
header('Content-Type: application/json');

// Fetch POST data
$id = $_POST['id'];
$cname = $_POST['cname'];
$wnumber = $_POST['wnumber'];
$username = $_POST['username'];

// Validar si se envió una contraseña
$password = isset($_POST['password']) && trim($_POST['password']) !== '' ? sha1($_POST['password']) : null;

// Verificar si el usuario existe
$checkQuery = "SELECT * FROM `admin` WHERE `id` = '$id'";
$checkResult = $conn->query($checkQuery);

if ($checkResult->num_rows > 0) {
    // Usuario existente: actualizar datos
    if ($password) {
        $query = "UPDATE `admin` SET `username` = '$username', `name` = '$cname', `contact_number` = '$wnumber', `password` = '$password' WHERE `id` = '$id'";
    } else {
        $query = "UPDATE `admin` SET `username` = '$username', `name` = '$cname', `contact_number` = '$wnumber' WHERE `id` = '$id'";
    }

    // Ejecutar la consulta de actualización
    if ($conn->query($query) === TRUE) {
        echo json_encode(['status' => true, 'message' => 'Usuario actualizado correctamente.']);
    } else {
        echo json_encode(['status' => false, 'message' => 'Error al actualizar el usuario.']);
    }
} else {
    // Si el usuario no existe, devolver error
    echo json_encode(['status' => false, 'message' => 'Usuario no encontrado.']);
}
?>
