<?php
include("../include/conn.php");

if (isset($_POST['id']) && isset($_POST['end_date'])) {
    $id = mysqli_real_escape_string($conn, $_POST['id']);
    $end_date = mysqli_real_escape_string($conn, $_POST['end_date']);

    $query = "UPDATE users SET end_date = '$end_date' WHERE id = '$id'";
    $result = mysqli_query($conn, $query);

    if ($result) {
        echo json_encode(['status' => 'success', 'message' => 'End date updated successfully.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to update end date.']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request.']);
}
?>