<?php
include("../include/conn.php");
include("../include/function.php");
header('Content-Type: application/json');

$id = post('id');
$id = mysqli_real_escape_string($conn, $id);

$sql = "DELETE FROM `users` WHERE `id` = '$id'";

if ($conn->query($sql) === TRUE) {
    echo json_encode(['message' => 'User deleted successfully.']);
} else {
    echo json_encode(['message' => 'Failed to delete User.']);
}
?>
