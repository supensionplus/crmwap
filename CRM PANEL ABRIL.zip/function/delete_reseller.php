<?php
include("../include/conn.php");
include("../include/function.php");
header('Content-Type: application/json');
$id = $_POST['id'];

$query = "DELETE FROM `admin` WHERE `id` = '$id'";

if ($conn->query($query) === TRUE) {
    echo json_encode(['message' => 'Deleted successfully.']);
} else {
    echo json_encode(['message' => 'Failed.']);
}
?>
