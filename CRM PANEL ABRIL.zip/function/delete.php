<?php
include("../include/conn.php");
include("../include/function.php");

// global $conn;

$id = $_POST["id"];

$query = "DELETE FROM `users` WHERE id=$id";
$conn->query($query);

header('Location: '.'../all-licenses.php');

// $ssql = "delete from users where id='$id'";

// $conexion->query($ssql);
