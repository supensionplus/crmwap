<?php
include("../include/conn.php");
include("../include/function.php");
header('Content-Type: application/json');
$id = $_POST['id'];

$query = "DELETE FROM `users` WHERE `id` = '$id'";

if ($conn->query($query) === TRUE) {
    echo json_encode(['message' => 'Reseller deleted successfully.']);
} else {
    echo json_encode(['message' => 'Failed to delete reseller.']);
}