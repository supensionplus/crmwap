<?php
session_start();
include("../include/conn.php");
include("../include/function.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Encriptar contraseña con sha1
    $hashedPassword = sha1($password);

    // Consulta segura usando declaraciones preparadas
    $stmt = $conn->prepare("SELECT * FROM admin WHERE username = ? AND password = ? AND status = 'true'");
    $stmt->bind_param("ss", $username, $hashedPassword);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Configurar variables de sesión
        $_SESSION['login'] = true;
        $_SESSION['id'] = $row['id'];
        $_SESSION['username'] = $row['username'];
        $_SESSION['user_type'] = $row['user_type'];
        $_SESSION['wsp'] = $row['contact_number']; // Suponiendo que tienes un campo así
        $_SESSION['name'] = $row['name']; // Nombre completo del usuario


        // Respuesta exitosa
        echo 'success';
        exit();
    } else {
        // Respuesta de fallo
        echo 'failure';
        exit();
    }
}
