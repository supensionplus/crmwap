<?php
include("../include/conn.php");
include("../include/function.php");

$response = array();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $wnumber = $_POST['wnumber'];
    $validity = $_POST['validity'];
    $cname = $_POST['cname'];
    $email = $_POST['email'];
    $admin_id = $_SESSION['id'];

    // Check for empty or null values
    if (empty($wnumber) || empty($validity) || empty($cname)) {
        $response['status'] = false;
        $response['message'] = "Por favor, complete todos los campos requeridos.";
    } else {
        $today = date("Y-m-d H:i:s"); // Use a more standard date format
        $licenseKey = generate_license();
        $futureDate = date("Y-m-d H:i:s", strtotime("+$validity days"));

        $query = "INSERT INTO `users` (`user_id`,`customer_name`,`whatsapp_number`, `license_key`, `email`, `act_date`, `end_date`, `life_time`, `plan_type`) VALUES ('$admin_id','$cname','$wnumber', '$licenseKey','$email', '$today', '$futureDate', 'false', 'Premium')";

        if ($conn->query($query) === TRUE) {
            $response['status'] = true;
            $response['message'] = "$licenseKey";
        } else {
            $response['status'] = false;
            $response['message'] = "Error al insertar los datos: " . $conn->error;
        }
        // if (check_number($wnumber) == true) {
        //     $response['status'] = false;
        //     $response['message'] = "El número de WhatsApp ya existe.";
        // } else {
        //     $today = date("Y-m-d H:i:s"); // Use a more standard date format
        //     $licenseKey = generate_license();
        //     $futureDate = date("Y-m-d H:i:s", strtotime("+$validity days"));

        //     $query = "INSERT INTO `users` (`user_id`,`customer_name`,`whatsapp_number`, `license_key`, `act_date`, `end_date`, `life_time`, `plan_type`) VALUES ('$admin_id','$cname','$wnumber', '$licenseKey', '$today', '$futureDate', 'false', 'Premium')";

        //     if ($conn->query($query) === TRUE) {
        //         $response['status'] = true;
        //         $response['message'] = "Clave de licencia generada: $licenseKey";
        //     } else {
        //         $response['status'] = false;
        //         $response['message'] = "Error al insertar los datos: " . $conn->error;
        //     }
        // }
    }
} else {
    $response['status'] = false;
    $response['message'] = "Método de solicitud no válido.";
}

// Set the content type to JSON
header('Content-Type: application/json');

// Encode the response array as JSON and send it back to the client
echo json_encode($response);
?>
